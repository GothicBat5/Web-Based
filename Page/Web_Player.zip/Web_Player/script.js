const AUDIO_PATTERN = /\.(mp3|wav|ogg|m4a|aac|flac|opus|webm)$/i;
const SEEK_RESOLUTION = 1000;
const SKIP_SECONDS = 5;
const RESTART_THRESHOLD_SECONDS = 3;
const INITIAL_VOLUME = 0.75;

const $ = (selector) => document.querySelector(selector);

const elements = {
  fileInput: $("#fileInput"),
  folderInput: $("#folderInput"),
  list: $("#list"),
  search: $("#search"),
  status: $("#status"),
  count: $("#count"),
  currentTitle: $("#currentTitle"),
  currentSub: $("#currentSub"),
  miniTitle: $("#miniTitle"),
  miniSub: $("#miniSub"),
  play: $("#play"),
  shuffle: $("#shuffle"),
  repeat: $("#repeat"),
  seek: $("#seek"),
  elapsed: $("#elapsed"),
  duration: $("#duration"),
  volume: $("#volume"),
  dropzone: $("#dropzone"),
};

const audio = new Audio();
audio.volume = INITIAL_VOLUME;

const state = {
  tracks: [],
  currentId: null,
  currentUrl: null,
  query: "",
  shuffle: false,
  nextId: 1,
};

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) {
    return "0:00";
  }

  const minutes = Math.floor(seconds / 60);
  const remainder = Math.floor(seconds % 60);

  return `${minutes}:${String(remainder).padStart(2, "0")}`;
}

function titleFromFile(file) {
  return file.name.replace(/\.[^.]+$/, "").replace(/_/g, " ");
}

function fileKey(file) {
  const path = file.webkitRelativePath || file.name;

  return `${path}|${file.size}|${file.lastModified}`;
}

function createElement(tag, className, text) {
  const element = document.createElement(tag);

  element.className = className;
  element.textContent = text;

  return element;
}

function naturalCompare(a, b) {
  return a.title.localeCompare(b.title, undefined, {
    numeric: true,
    sensitivity: "base",
  });
}

function currentTrack() {
  return state.tracks.find((track) => track.id === state.currentId) || null;
}

function currentIndex() {
  return state.tracks.findIndex((track) => track.id === state.currentId);
}

/* Library */

function addFiles(fileList) {
  const knownKeys = new Set(state.tracks.map((track) => track.key));
  const added = [];

  for (const file of fileList) {
    const key = fileKey(file);

    if (!AUDIO_PATTERN.test(file.name) || knownKeys.has(key)) {
      continue;
    }

    knownKeys.add(key);
    added.push({
      id: state.nextId++,
      key,
      file,
      title: titleFromFile(file),
      duration: null,
    });
  }

  if (!added.length) {
    setStatus("No new audio files found.");
    return;
  }

  state.tracks = [...state.tracks, ...added].sort(naturalCompare);
  added.forEach(loadDuration);

  setStatus(`${added.length} song${added.length === 1 ? "" : "s"} added.`);
  renderList();
}

function clearLibrary() {
  stopPlayback();
  state.tracks = [];
  state.currentId = null;
  elements.search.value = "";
  state.query = "";

  setStatus("Library cleared.");
  updateNowPlaying(null);
  renderList();
}

function loadDuration(track) {
  const probe = new Audio();
  const url = URL.createObjectURL(track.file);

  probe.preload = "metadata";
  probe.src = url;

  probe.onloadedmetadata = () => {
    track.duration = probe.duration;
    URL.revokeObjectURL(url);
    updateRowDuration(track);
  };

  probe.onerror = () => URL.revokeObjectURL(url);
}

/* Rendering */

function setStatus(message) {
  elements.status.textContent = message;
}

function visibleTracks() {
  const query = state.query.toLowerCase();

  return state.tracks
    .map((track, index) => ({ track, number: index + 1 }))
    .filter(({ track }) => track.title.toLowerCase().includes(query));
}

function createRow({ track, number }) {
  const row = document.createElement("div");
  const numberCell = createElement("div", "num", String(number).padStart(2, "0"));
  const nameCell = createElement("div", "songname", track.title);
  const durationCell = createElement("div", "duration", formatDuration(track));

  row.className = "song";
  row.dataset.id = track.id;
  row.dataset.number = numberCell.textContent;
  nameCell.title = track.title;
  row.append(numberCell, nameCell, durationCell);
  row.addEventListener("click", () => playTrack(track));

  return row;
}

function formatDuration(track) {
  return track.duration === null ? "—:—" : formatTime(track.duration);
}

function renderList() {
  const rows = visibleTracks();

  elements.count.textContent = `(${state.tracks.length})`;

  if (!rows.length) {
    const message = state.tracks.length
      ? "No matches."
      : "Add songs or a folder to fill your library.";

    elements.list.replaceChildren(createElement("div", "empty", message));
    return;
  }

  elements.list.replaceChildren(...rows.map(createRow));
  refreshActiveRow();
}

function refreshActiveRow() {
  for (const row of elements.list.querySelectorAll(".song")) {
    const isActive = Number(row.dataset.id) === state.currentId;
    const isPlaying = isActive && !audio.paused;

    row.classList.toggle("active", isActive);
    row.querySelector(".num").textContent = isPlaying ? "♫" : row.dataset.number;
  }
}

function updateRowDuration(track) {
  const cell = elements.list.querySelector(`[data-id="${track.id}"] .duration`);

  if (cell) {
    cell.textContent = formatDuration(track);
  }
}

function updateNowPlaying(track) {
  const title = track ? track.title : "Nothing playing";
  const sub = track ? "Local file" : "Add some music to begin.";

  elements.currentTitle.textContent = title;
  elements.currentSub.textContent = sub;
  elements.miniTitle.textContent = title;
  elements.miniSub.textContent = track ? sub : "Local library";
}

function resetTimeline() {
  elements.seek.value = 0;
  elements.elapsed.textContent = "0:00";
  elements.duration.textContent = "0:00";
}

/* Playback */

function releaseCurrentUrl() {
  if (state.currentUrl) {
    URL.revokeObjectURL(state.currentUrl);
    state.currentUrl = null;
  }
}

function stopPlayback() {
  audio.pause();
  audio.removeAttribute("src");
  audio.load();
  releaseCurrentUrl();
  resetTimeline();
}

function playTrack(track) {
  if (!track) {
    return;
  }

  releaseCurrentUrl();
  state.currentId = track.id;
  state.currentUrl = URL.createObjectURL(track.file);
  audio.src = state.currentUrl;
  audio.play().catch(() => {});

  updateNowPlaying(track);
  refreshActiveRow();
}

function togglePlay() {
  if (!currentTrack()) {
    playTrack(state.tracks[0]);
    return;
  }

  if (audio.paused) {
    audio.play();
  } else {
    audio.pause();
  }
}

function randomTrack() {
  if (state.tracks.length < 2) {
    return state.tracks[0];
  }

  let candidate;

  do {
    candidate = state.tracks[Math.floor(Math.random() * state.tracks.length)];
  } while (candidate.id === state.currentId);

  return candidate;
}

function playNext() {
  if (!state.tracks.length) {
    return;
  }

  if (state.shuffle) {
    playTrack(randomTrack());
    return;
  }

  const nextIndex = (currentIndex() + 1) % state.tracks.length;

  playTrack(state.tracks[nextIndex]);
}

function playPrevious() {
  if (!state.tracks.length) {
    return;
  }

  if (audio.currentTime > RESTART_THRESHOLD_SECONDS) {
    audio.currentTime = 0;
    return;
  }

  const count = state.tracks.length;
  const previousIndex = (currentIndex() - 1 + count) % count;

  playTrack(state.tracks[previousIndex]);
}

function skip(seconds) {
  const target = audio.currentTime + seconds;

  audio.currentTime = Math.min(Math.max(0, target), audio.duration || 0);
}

function toggleShuffle() {
  state.shuffle = !state.shuffle;
  elements.shuffle.setAttribute("aria-pressed", String(state.shuffle));
}

function toggleRepeat() {
  audio.loop = !audio.loop;
  elements.repeat.setAttribute("aria-pressed", String(audio.loop));
}

/* Dropped folders */

function readEntry(entry) {
  if (entry.isFile) {
    return new Promise((resolve) => entry.file(resolve, () => resolve(null)));
  }

  return readDirectory(entry);
}

async function readDirectory(directory) {
  const reader = directory.createReader();
  const files = [];
  let batch;

  do {
    batch = await new Promise((resolve) => reader.readEntries(resolve, () => resolve([])));

    for (const entry of batch) {
      const result = await readEntry(entry);

      files.push(...[result].flat().filter(Boolean));
    }
  } while (batch.length);

  return files;
}

async function filesFromDrop(dataTransfer) {
  const entries = [...dataTransfer.items]
    .map((item) => item.webkitGetAsEntry && item.webkitGetAsEntry())
    .filter(Boolean);

  if (!entries.length) {
    return [...dataTransfer.files];
  }

  const groups = await Promise.all(entries.map(readEntry));

  return groups.flat().filter(Boolean);
}

/* Events */

function bindPickers() {
  const openFiles = () => elements.fileInput.click();
  const openFolder = () => elements.folderInput.click();

  $("#addFilesTop").addEventListener("click", openFiles);
  $("#addFilesMain").addEventListener("click", openFiles);
  $("#addFolderTop").addEventListener("click", openFolder);
  $("#addFolderMain").addEventListener("click", openFolder);

  for (const input of [elements.fileInput, elements.folderInput]) {
    input.addEventListener("change", () => {
      addFiles(input.files);
      input.value = "";
    });
  }
}

function bindDragAndDrop() {
  let depth = 0;

  document.addEventListener("dragenter", (event) => {
    event.preventDefault();
    depth++;
    elements.dropzone.classList.add("visible");
  });

  document.addEventListener("dragleave", () => {
    depth = Math.max(0, depth - 1);

    if (!depth) {
      elements.dropzone.classList.remove("visible");
    }
  });

  document.addEventListener("dragover", (event) => event.preventDefault());

  document.addEventListener("drop", async (event) => {
    event.preventDefault();
    depth = 0;
    elements.dropzone.classList.remove("visible");
    addFiles(await filesFromDrop(event.dataTransfer));
  });
}

function bindPlayerControls() {
  $("#prev").addEventListener("click", playPrevious);
  $("#next").addEventListener("click", playNext);
  elements.play.addEventListener("click", togglePlay);
  elements.shuffle.addEventListener("click", toggleShuffle);
  elements.repeat.addEventListener("click", toggleRepeat);
  $("#clear").addEventListener("click", clearLibrary);

  elements.search.addEventListener("input", () => {
    state.query = elements.search.value.trim();
    renderList();
  });

  elements.seek.addEventListener("input", () => {
    if (audio.duration) {
      audio.currentTime = (Number(elements.seek.value) / SEEK_RESOLUTION) * audio.duration;
    }
  });

  elements.volume.addEventListener("input", () => {
    audio.volume = Number(elements.volume.value);
  });
}

function bindAudioEvents() {
  audio.addEventListener("play", () => {
    elements.play.textContent = "⏸";
    refreshActiveRow();
  });

  audio.addEventListener("pause", () => {
    elements.play.textContent = "▶";
    refreshActiveRow();
  });

  audio.addEventListener("timeupdate", () => {
    if (!audio.duration) {
      return;
    }

    elements.seek.value = (audio.currentTime / audio.duration) * SEEK_RESOLUTION;
    elements.elapsed.textContent = formatTime(audio.currentTime);
    elements.duration.textContent = formatTime(audio.duration);
  });

  audio.addEventListener("ended", playNext);
}

function bindKeyboard() {
  document.addEventListener("keydown", (event) => {
    const typing = ["INPUT", "TEXTAREA"].includes(document.activeElement.tagName);

    if (typing) {
      return;
    }

    if (event.code === "Space") {
      event.preventDefault();
      togglePlay();
    } else if (event.code === "ArrowRight") {
      skip(SKIP_SECONDS);
    } else if (event.code === "ArrowLeft") {
      skip(-SKIP_SECONDS);
    }
  });
}

function init() {
  bindPickers();
  bindDragAndDrop();
  bindPlayerControls();
  bindAudioEvents();
  bindKeyboard();
  renderList();
}

init();
